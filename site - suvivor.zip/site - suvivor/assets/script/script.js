function mostra_dime() {

    dime.style.display="block";
    inst.style.display="none";
    item.style.display="none";
    
}

function mostra_inst() {
    dime.style.display="none";
    inst.style.display="block";
    item.style.display="none";
    
}

function mostra_item() {
    dime.style.display="none";
    inst.style.display="none";
    item.style.display="block";
    
}
